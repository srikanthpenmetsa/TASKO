﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tasko.Common
{
    /// <summary>
    /// It is the class to have common business logic required by both vendor and customer
    /// </summary>
    public class Common
    {
        //// comment added   
    }
}
